# @gamerfy/bot

SDK oficial para escrever bots do Gamerfy em Node: mensagens, eventos em tempo real e voz.
O bot lê mensagens, escreve, modera e fala numa sala de voz pela API do Gamerfy — sem
saber que existe LiveKit do outro lado.

Precisa de **Node 22** ou mais novo (o `WebSocket` global vem dele) e fala a **versão 1**
do gateway. Você escreve em camelCase; o SDK conversa em snake_case com o Gamerfy e
valida com zod tudo o que chega, antes de qualquer callback seu.

## Instalar

O pacote está publicado no npm (`@gamerfy/bot`, Node 22 ou mais novo, licença MIT):

```sh
npm install @gamerfy/bot
```

e o código é `import { Bot } from '@gamerfy/bot'`.

Para mexer no próprio SDK — testar uma mudança, rodar os exemplos —, o caminho é de
dentro deste repositório:

```sh
npm install                    # na raiz do repositório
cd packages/bot-sdk
GAMERFY_BOT_TOKEN=gfb_… npx tsx examples/dj.ts
```

Os exemplos importam `../src/index.js` porque moram ao lado do código.

## 1. Criar o app e ligar o bot

Na aba **Desenvolvedor** das configurações da conta, no seu app, o botão **Bot** abre a
seção do bot:

1. **Ligar bot** cria a conta do bot. O `username` sai do nome do app (minúsculas, espaço
   vira `_`, com sufixo numérico se já existir) e o nome exibido é o nome do app.
2. O **token** (`gfb_` + 40 caracteres) aparece **uma única vez**, com um botão de copiar:
   "Guarde agora: o token não aparece de novo". Guarde-o como senha, num `.env` ou no
   cofre do seu servidor — nunca no código.
3. Preencha **ícone**, **descrição** e **link da política de privacidade**, marque as
   **permissões que o bot pede** e clique em **Salvar perfil**. O link de adicionar só
   funciona com o perfil completo; enquanto falta algo, a própria seção diz o que falta.
4. **Gerar novo token** invalida o anterior na hora e fecha a conexão do bot com o código
   4003. É a revogação: use-a se o token escapar.

Renomear o app muda o nome exibido do bot, nunca o `username`. Apagar o app tira o bot de
todos os servidores, fecha o gateway com 4005 e deixa as mensagens que ele escreveu
assinadas por "Bot removido".

## 2. Adicionar o bot a um servidor

O link é `https://gamerfy.gg/bot/<client_id>`, e está na seção Bot com um botão de copiar.
Quem abre escolhe o servidor (entre os que administra), vê as permissões pedidas já
marcadas e pode desmarcar o que quiser.

O que o bot tem num servidor é **só** o que foi concedido nessa tela: o `@everyone` e os
cargos não somam nada para ele (o cargo Bot que ele recebe existe para aparecer agrupado
na lista de membros, e não carrega permissão). Duas consequências práticas:

- quem adiciona só concede permissões que **ele mesmo** tem, e só bits que o app pede;
- a permissão que faltar aparece como `missing_permission`, com o nome do bit em
  `details.permission` — **Falar** (`SPEAK`), por exemplo, sem a qual o bot não entra em
  sala de voz nenhuma.

Para mudar depois: menu do membro bot → **Permissões do bot**.

## 3. Conectar

```ts
import { Bot } from '@gamerfy/bot';

const bot = new Bot({ token: process.env.GAMERFY_BOT_TOKEN! });

bot.on('ready', (user) => console.log(`conectado como ${user.displayName} (app ${user.appId})`));

await bot.connect();
```

`connect()` resolve no primeiro `ready` — a partir dali `bot.user` e `bot.guilds` estão
preenchidos. Chamar de novo com a conexão de pé devolve a **mesma** promessa (duas
conexões no mesmo token derrubariam uma das duas); depois de uma falha, a próxima chamada
é uma tentativa nova de verdade.

Opções do construtor:

| Opção | Para quê |
|---|---|
| `token` | o `gfb_…` da aba Desenvolvedor |
| `apiUrl` | base da API; por omissão `https://api.gamerfy.gg`. Precisa de `http://` ou `https://` — sem esquema o construtor recusa com `invalid_api_url` |
| `gatewayUrl` | **derivado do `apiUrl`** quando omitido; dado à mão, aceita `ws://`, `wss://`, `http://` ou `https://` (os dois últimos o `WebSocket` lê como `ws://` e `wss://`), sem `#` — o resto o construtor recusa com `invalid_gateway_url` |
| `connectTimeoutMs` | quanto o `connect()` espera pelo `ready` (30 s) |
| `iceAdditionalHostAddresses` | endereços extras de ICE — `['127.0.0.1']` contra o LiveKit do compose |
| `voice.transport` | `'auto'` (padrão) tenta o caminho direto e, se o ICE não sobe, refaz a entrada por TURN com os servidores que a resposta trouxe; `'relay'` entra por TURN desde o começo (§8, "Rede"). Também por entrada: `voice.join(id, { transport })`. Outro valor: recusa com `invalid_voice_transport` |
| `restTimeoutMs` | quanto uma chamada REST (`messages.send`, `channels.fetch`…) espera antes de ser recusada com `timeout` (30 s por omissão); precisa ser um inteiro positivo de milissegundos, ou o construtor recusa com `invalid_rest_timeout_ms` |
| `logger` | para onde vai um `error` sem nenhum `on('error', …)` ouvindo (`console` por omissão) — um objeto com `error(message, error)`, como o próprio `console` |
| `fetch`, `WebSocketImpl` | trocar o transporte (teste, proxy próprio) |

O `gatewayUrl` ser **derivado** e não ter um padrão próprio é de propósito: apontar o
`apiUrl` para a sua máquina e esquecer o gateway seria escrever no seu backend e escutar a
**produção**. Contra um backend local, `apiUrl` sozinho basta:

```ts
const bot = new Bot({ token, apiUrl: 'http://127.0.0.1:4502/api/public' });
// gateway: ws://127.0.0.1:4502/api/public/v1/gateway
```

`bot.destroy()` desliga tudo, para o programa poder sair: fecha a conexão, cancela a
reconexão pendente, faz um `connect()` ainda em espera falhar com `connect_aborted` e **sai
de toda sala de voz** que o bot abriu — inclusive a de um `voice.join()` ainda a caminho,
que rejeita com `voice_join_aborted` assim que chega. A parte do gateway acontece na hora;
a da voz é a promessa que ele devolve, e ela nunca rejeita:

```ts
process.on('SIGINT', () => {
  void bot.destroy().then(() => process.exit(0));
});
```

É o `destroy()` que solta o programa: uma sala de voz que ninguém deixou mantém o WebRTC
aberto — e o processo de pé, com o bot sentado na sala.

## 4. Eventos

```ts
bot.on('message', (message) => { /* … */ });
```

| Evento | O que chega |
|---|---|
| `ready` | a conta do bot e o app (`BotSelf`); refaz `bot.guilds` do zero |
| `message`, `messageUpdate` | a mensagem (`Message`) |
| `messageDelete` | `{ id, guildId, channelId }` |
| `guildJoin` | o servidor (`CachedGuild`) |
| `guildLeave` | o `guildId` — expulsão, banimento ou saída |
| `memberJoin` | `{ guildId, user, nickname, joinedAt }` |
| `memberLeave` | `{ guildId, userId }` |
| `voiceStateUpdate` | `{ guildId, userId, channelId }`, com `channelId: null` ao sair |
| `voicePermission` | `{ guildId, channelId, canSpeak }` — *Falar* tirada de uma sala em que o bot está, ou devolvida a ela (§8) |
| `resumed` | `{ replayed }` — a conexão caiu e voltou **sem** `ready`: `bot.guilds` continua valendo, e `replayed` é quantos eventos chegaram atrasados, já entregues aos listeners de sempre (§10) |
| `error` | uma falha que o SDK pegou no caminho até você |
| `disconnect` | `{ code, willReconnect }` a cada fechamento |

Duas regras sobre erros, e elas são opostas:

- o que o SDK pega (um quadro fora do formato, o gateway inalcançável por um instante) vai
  para o evento `error`, e **a reconexão continua**. Sem nenhum listener de `error` o SDK
  imprime a falha em `console.error` em vez de derrubar o programa;
- um `throw` **seu**, dentro de um listener, é fatal — é a convenção do Node, e vale
  igual para o `throw` síncrono e para a promessa rejeitada de um listener `async`. Se o
  seu bot não pode morrer por causa de um 403, ponha o `try/catch` você (é o que o
  `examples/moderator.ts` faz).

O gateway manda também `channel.created`, `channel.updated`, `channel.deleted` e
`guild.permissions_updated`, e o SDK **escolhe** não repassá-los como eventos nesta versão:
ele os aplica em `bot.guilds` em silêncio e não acorda ninguém. O motivo é o aviso de
permissão: ele pode trazer uma sala recém-concedida só com id e permissões, o SDK então
recarrega as salas daquele servidor sozinho (§6), e um evento disparado antes dessa recarga
entregaria ao seu listener um quadro pela metade. Quem precisa reagir lê `bot.guilds` de
novo, ou reage à recusa que vier. A exceção é a voz: um aviso que tira ou devolve *Falar*
numa sala em que o bot está vira um `voicePermission` (§8) — depois de o SDK já ter agido.

## 5. Mensagens

```ts
const sent = await bot.messages.send(channelId, 'Tocando lofi');   // needs Ver canais + Enviar mensagens
await bot.messages.delete(channelId, sent.id);                     // its own message, or Gerenciar mensagens
```

`messages.send` devolve a mensagem que o Gamerfy escreveu. O texto vai até 2000
caracteres — acima disso o servidor recusa com `invalid_body`, o SDK não corta nada por
você. Bots não enviam anexos nesta fase.

### `content: null` e a permissão Ler mensagens

`message.content` é `null` — e `attachments` vem vazio — quando o bot **não pode ler**
aquela mensagem. O filtro é do servidor e libera o texto em três casos: o bot tem **Ler
mensagens** na sala, o bot está entre as menções, ou o bot é o autor.

É por isso que um bot de comando funciona sem Ler mensagens: quem escreve `@meu_bot
tocar` está mencionando o bot, e o texto chega inteiro. Já um moderador que julga tudo o
que passa no canal precisa da permissão — e quem o adiciona vê o aviso "este bot vai ler
as conversas dos canais que enxerga".

```ts
bot.on('message', (message) => {
  if (message.content === null) return;          // nothing to read here
  if (message.mentionsMe) { /* somebody is talking to me */ }
});
```

`mentionsMe` é `false` até o primeiro `ready`: antes dele o bot não sabe o próprio id.

## 6. Servidores, salas e permissões

`bot.guilds` é um `ReadonlyMap<string, CachedGuild>` mantido pelos eventos:

```ts
for (const guild of bot.guilds.values()) {
  console.log(guild.name, guild.channels.size, guild.permissions);   // permissions is a bigint
}
const channelId = bot.voiceChannelOf(guildId, userId);               // somebody's room, or null
```

O mapa não aceita `set` nem `delete`, **mas os servidores dentro dele são objetos
mutáveis**: os eventos editam esses `Map` no lugar, de propósito, para quem guardou um
deles estar sempre lendo o quadro atual. Leia; nunca escreva. Um campo que você
sobrescrever fica sobrescrito até o próximo `ready`, e nada avisa.

Um `ready` **refaz** tudo, nunca funde: cada `ready` novo traz a verdade inteira sobre
o que o bot enxerga naquele momento, e os eventos de antes dele se perdem — mas isso só
acontece quando a reconexão não consegue retomar (§10); uma que retoma chega como
`resumed`, sem `ready`, e o mapa continua sendo o de antes.

`channels.fetch(guildId)` recarrega as salas de um servidor:

```ts
const channels = await bot.channels.fetch(guildId);
```

Ela existe porque o aviso de permissão nova traz a sala recém-concedida **só com id e
permissões** — sem nome, tipo nem posição. O SDK chama essa recarga sozinho nesse caso;
ela é pública para você repetir depois de qualquer recusa que sugira quadro velho. Uma
resposta que chegar atrasada (de uma recarga anterior, ou de antes de um `ready` novo) é
descartada em vez de ressuscitar uma sala que o bot já perdeu.

`guild.permissions` e `channel.permissions` são `bigint`, um bit por permissão. O SDK ainda
não exporta constantes para eles; os sete bits que as rotas de bot conferem são estes:

| Permissão (como a tela escreve) | `details.permission` na recusa | Bit | Valor |
|---|---|---|---|
| Ver canais | `VIEW_CHANNEL` | `1n << 0n` | 1 |
| Enviar mensagens | `SEND_MESSAGES` | `1n << 1n` | 2 |
| Gerenciar mensagens | `MANAGE_MESSAGES` | `1n << 2n` | 4 |
| Expulsar membros | `KICK_MEMBERS` | `1n << 6n` | 64 |
| Conectar | `CONNECT` | `1n << 8n` | 256 |
| Falar | `SPEAK` | `1n << 9n` | 512 |
| Ler mensagens | — nunca recusa: sem ela, `content` chega `null` (§5) | `1n << 13n` | 8192 |

```ts
const SPEAK = 1n << 9n;
const room = bot.guilds.get(guildId)?.channels.get(channelId);
if (room !== undefined && (room.permissions & SPEAK) === SPEAK) { /* the bot may speak there */ }
```

O valor de uma sala já traz o que a sala muda (as sobrescritas dela), e um bot com
**Administrador** (`1n << 30n`) recebe todos os bits ligados, sem teste à parte. É um
retrato do último aviso: se a recusa vier mesmo assim, o `missing_permission` nomeia o
bit que faltou.

## 7. Moderar

```ts
await bot.members.kick(guildId, userId);              // needs Expulsar membros
await bot.members.ban(guildId, userId, 'spam');       // needs Expulsar membros; the reason is optional
await bot.members.leave(guildId);                     // the bot leaves the server
```

## 8. Voz

```ts
const voice = await bot.voice.join(channelId);   // needs Ver canais + Conectar + Falar
await voice.play('./lofi.ogg');                  // plays to the end
voice.stop();                                    // interrupts it
await voice.leave();                             // hangs up and leaves the room
```

O que um bot pode e não pode na voz:

- **só fala.** O token que o Gamerfy assina publica o microfone e não assina nada: o bot
  nunca recebe o áudio da sala. Na sala ele aparece como qualquer pessoa — rosto na lista,
  anel de fala aceso, e o áudio entra na live de quem estiver transmitindo.
- **sem Falar não entra.** Sem `SPEAK` (ou sem `CONNECT`, ou sem `VIEW_CHANNEL`) a entrada
  é recusada com `missing_permission`.
- **Falar some no meio da chamada, o microfone some junto — e volta com ela.** Quem tira
  *Falar* do bot com ele numa sala **não o tira da sala**: o servidor de mídia derruba a
  faixa do microfone **na hora**, e o SDK interrompe a faixa que estava tocando — o
  `play()` em andamento rejeita com `missing_permission` (um `GamerfyApiError`, com
  `details.permission: 'SPEAK'`), `voice.muted` fica `true` e qualquer `play()` novo
  rejeita com o mesmo código, em vez de mandar pacotes para uma faixa que não existe mais.
  Quando *Falar* volta, o SDK **refaz a sessão WHIP sozinho** (sai e entra na mesma sala,
  na mesma `VoiceConnection`), limpa `muted` e avisa pelo evento `voicePermission`
  (`{ guildId, channelId, canSpeak }`): um `play()` dentro desse listener já toca. Se a
  volta falhar (o servidor de mídia fora do ar, por exemplo), o erro vai para `error`, a
  conexão continua muda e o próximo aviso de permissão com *Falar* tenta de novo. Uma sala
  que **some** do aviso (o bot perdeu *Ver canais* dela) não é lida como perda de *Falar*:
  o SDK não mexe na conexão (§14).
- **uma sala por servidor.** Entrar numa segunda sala do mesmo servidor tira o bot da
  primeira **na hora**, antes de a entrada nova acontecer — e só no mesmo servidor: a sala
  de um servidor diferente fica como está. O SDK não desliga a conexão antiga por você:
  chame `leave()` nela antes, porque depois do segundo `join` ela continua parecendo viva
  — `play()` resolve normalmente e a sala não ouve nada.
- **uma sala em cada servidor.** Servidores diferentes não se tocam: um bot tocando em
  dois servidores ao mesmo tempo fica nas duas salas, e cada `leave()` desliga a sua.
- **em cada servidor, só a sessão mais recente se desliga.** Um `join` novo no mesmo
  servidor aposenta a sessão anterior dali, então o `leave()` da conexão antiga recebe um
  404 que o SDK engole — ele ainda fecha o WebRTC daquele lado.
- **no máximo 6 entradas por minuto na mesma sala** (§11). Conta toda entrada que passa
  da porta (permissões conferidas), aceita ou não pelo servidor de mídia.

### Rede: NAT, containers e TURN

A voz vai por WebRTC, e quem abre a conexão é a máquina do bot: `voice.join()` junta
todos os candidatos ICE **antes** de mandar a oferta (não existe trickle nesta fase), o
Gamerfy responde, e o WebRTC tenta chegar ao servidor de mídia por UDP. Atrás de um NAT
comum isso passa, porque é o bot quem inicia; o que não passa é uma rede que **bloqueia
UDP** até o servidor de mídia — um container sem UDP de saída, uma rede corporativa.

Os servidores TURN só chegam **na resposta** (o cabeçalho `Link`), e o WebRTC só os aceita
**antes** da oferta. Então o SDK aprende e tenta de novo — dois modos:

- **`transport: 'auto'`** (padrão): a primeira entrada é direta. Se o ICE não sobe em 15 s,
  o SDK desliga essa sessão, cria um WebRTC novo **só por relay** com os servidores que a
  resposta trouxe (TLS primeiro: `turns:…:5349`, depois TCP, depois UDP) e entra de novo.
  Deu certo → o processo lembra (`relayNeeded`) e as próximas entradas já vão por relay,
  sem gastar os 15 s. Falhou também → `voice.join()` rejeita com `ice_failed`
  (`GamerfyApiError` 502): `details.paths` diz o que foi tentado (`['direct', 'relay']`),
  `details.servers` os endereços TURN que a resposta ofereceu e `details.server` o **único
  que o werift discou de fato** — ele usa só a primeira entrada utilizável da lista (ordem
  TLS → TCP → UDP), então as outras nunca foram contatadas. Nunca as credenciais.
- **`transport: 'relay'`**: a primeira entrada existe só para ler os servidores — o SDK a
  desliga assim que lê o `Link`, sem esperar ICE — e a segunda entra por relay. Com os
  servidores já na memória do bot, é uma entrada só.

Os servidores ficam na memória do **bot** por até **4 minutos** (a credencial do TURN
vence antes do token) — cada `Bot` tem a sua, porque a credencial é de um participante; a
decisão "esta rede precisa de relay" é do processo — e são esquecidos no `destroy()`. Uma
entrada por relay que falha com servidores da memória esquece a memória e aprende **uma
vez** antes de desistir. Uma resposta **sem** servidor TURN faz o `'auto'` rejeitar com
`voice_connection_failed` (como antes) e o `'relay'` com `ice_failed` e `paths: []`.

**O custo:** a entrada por relay é **um `POST` a mais**, e os dois contam no teto de **6
entradas por minuto por bot e sala** (§11) — `'auto'` no primeiro erro e `'relay'` na
primeira entrada gastam duas vagas. Um servidor lembrado que falha custa **três** `POST`s
(a tentativa com o lembrado, aprender de novo, entrar por relay), o que deixa o pior caso
em **duas entradas por minuto**. `voice.path` diz por onde a conexão entrou e
`voice.iceServerUrls` o que a resposta ofereceu (sem credenciais): o `examples/dj.ts`
imprime os dois.

Contra o LiveKit do compose, na sua máquina, passe `iceAdditionalHostAddresses:
['127.0.0.1']`: o container só enxerga o seu processo pelo loopback.

### O áudio

`play()` aceita o caminho de um arquivo ou um stream legível, e o formato decide o
caminho que os bytes tomam:

| O que você passa | O que acontece |
|---|---|
| caminho `.ogg` / `.opus` | lido como está e enviado sem transcodificar — um pacote a cada 20 ms |
| qualquer outro caminho | passa pelo **`ffmpeg` da sua máquina** (mp3, wav, m4a, uma URL que o ffmpeg abra) |
| um stream | lido como Ogg Opus, sem transcodificar |

O ffmpeg roda **na máquina do bot**, nunca nos servidores do Gamerfy. Se ele não estiver
instalado, `play()` rejeita com `code: 'ffmpeg_not_found'`; se morrer no meio ou sair com
erro (arquivo corrompido, build sem libopus), com `code: 'ffmpeg_failed'`.

Essas falhas **não** são `GamerfyApiError`: são `VoiceSourceError`, as falhas da própria
voz, com os códigos do tipo `VoiceSourceErrorCode` — e `isVoiceSourceError` é o guarda:

```ts
import { isVoiceSourceError } from '@gamerfy/bot';

try {
  await voice.play('./musica.mp3');
} catch (error) {
  if (isVoiceSourceError(error) && error.code === 'ffmpeg_not_found') await bot.messages.send(channelId, 'Falta ffmpeg na máquina do bot.');
  else throw error;
}
```

| `code` | Quando |
|---|---|
| `voice_offer_failed` | o WebRTC desta máquina não montou a oferta (`voice.join()`) |
| `voice_connection_failed` | a entrada foi aceita, a conexão direta não subiu e a resposta não trouxe nenhum servidor TURN para tentar por relay (`voice.join()`; veja "Rede") |
| `voice_connection_left` | `play()` numa conexão que já saiu da sala |
| `already_playing` | `play()` com outra faixa tocando na mesma conexão |
| `invalid_audio_input` | `play()` com algo que não é caminho nem stream |
| `audio_not_ogg` | o stream, ou o arquivo `.ogg`/`.opus`, não é Ogg |
| `audio_not_opus` | é Ogg, mas não é Opus |
| `ffmpeg_not_found` | não há `ffmpeg` na máquina do bot |
| `ffmpeg_failed` | o ffmpeg não iniciou, saiu com erro ou morreu no meio da faixa |

Um caminho que não existe rejeita de dois jeitos, conforme a extensão. Um `.ogg` ou `.opus`
o SDK abre sozinho, e a falha é o `ENOENT` do próprio Node — que também tem `code`, mas não
é falha do SDK, e por isso o guarda diz não a ela. Qualquer outro caminho vai para o
ffmpeg, e é ele quem descobre que o arquivo não existe: `play()` rejeita com
`ffmpeg_failed`, com a queixa do ffmpeg na mensagem (ou com `ffmpeg_not_found`, se nem o
ffmpeg houver).

Cuidado com a extensão: um arquivo **chamado** `.ogg` nunca vê o ffmpeg. Se ele for Ogg
Vorbis (o conteúdo mais comum num `.ogg`), `play()` rejeita com `audio_not_opus`. Converta
antes, ou renomeie para o ffmpeg cuidar:

```sh
ffmpeg -i musica.mp3 -ac 2 -ar 48000 -c:a libopus -b:a 96k \
  -frame_duration 20 -application audio -page_duration 20000 musica.ogg
```

### Trocar de faixa

`stop()` libera o lugar **na mesma hora**, então o par `stop(); play(próxima)` funciona sem
esperar promessa nenhuma:

```ts
voice.stop();
void voice.play('./proxima.ogg');
```

Uma faixa por conexão: `play()` com outra tocando rejeita com `already_playing`, mandando
chamar `stop()` antes. A promessa da faixa **interrompida** resolve no `stop()`, mesmo com
a fonte travada — uma rádio que parou de mandar, um ffmpeg esperando a rede: o SDK deixa de
esperar por ela, mata o ffmpeg e encerra o stream que você passou (`destroy()`), do mesmo
jeito que um `for await` com `break` encerraria. `leave()` e `destroy()` fazem o mesmo,
então uma fonte travada — o ffmpeg, o arquivo que o SDK abriu, o stream que você passou —
não segura o programa.

Depois de `leave()` a conexão está encerrada e `play()` rejeita: para voltar à sala,
`voice.join()` de novo. Chamar `leave()` duas vezes não faz mal: a segunda não desliga de
novo, devolve a promessa da primeira — e é isso que faz o `destroy()` esperar um `leave()`
seu que ainda estava a caminho.

## 9. Erros

Toda recusa da conversa com o Gamerfy é um `GamerfyApiError` (as da própria voz são
`VoiceSourceError`, §8). **Compare o `code`**, nunca a mensagem e nunca o `status`:

```ts
import { GamerfyApiError } from '@gamerfy/bot';

try {
  await bot.messages.send(channelId, 'oi');
} catch (error) {
  if (error instanceof GamerfyApiError && error.code === 'rate_limited') {
    await new Promise((resolve) => setTimeout(resolve, error.retryAfterMs ?? 1000));
    return;
  }
  throw error;
}
```

O motivo de ser o `code` e não o número: parte dos códigos é **do Gamerfy**
(`missing_permission`, `rate_limited`, `channel_not_found`, `voice_unavailable`,
`invalid_token`, `bot_token_expired`…) e parte o **SDK cunha sozinho**, para falhas que o
envelope da API não cobre — `timeout` incluído: mesmo esperando bem menos que o Gamerfy
espera de si mesmo, é sempre o SDK que desiste da chamada, nunca a API que responde
"demorei demais".

| `code` | Quando |
|---|---|
| `invalid_response` | a resposta não é JSON, ou não tem a forma que esta versão do SDK conhece |
| `http_error` | veio um status sem envelope nenhum — o HTML 502 de um proxy |
| `timeout` | a chamada REST não respondeu dentro do `restTimeoutMs` — o SDK desistiu e abortou a chamada |
| `invalid_api_url` | o construtor recusou a `apiUrl`: sem `http://`/`https://`, ou com `?`/`#` |
| `invalid_gateway_url` | o construtor recusou a `gatewayUrl` dada à mão: não é `ws://`/`wss://`/`http://`/`https://`, ou traz `#` |
| `invalid_rest_timeout_ms` | o construtor recusou o `restTimeoutMs`: não é um inteiro positivo de milissegundos |
| `invalid_voice_transport` | o construtor (ou `voice.join(id, { transport })`) recusou o `transport`: só `'auto'` ou `'relay'` |
| `ice_failed` | a entrada foi aceita, mas a conexão não subiu por nenhum caminho que o SDK tinha: `details.paths` na ordem tentada, `details.servers` os endereços TURN que a resposta ofereceu e `details.server` o que o werift discou (ele usa só a primeira entrada utilizável, ordem TLS → TCP → UDP) — sem credenciais, §8, "Rede" |
| `gateway_timeout` | o gateway não mandou `ready` dentro do `connectTimeoutMs` |
| `gateway_closed` | o gateway fechou sem volta antes do `ready` (o código está em `details.close_code`) |
| `connect_aborted` | `destroy()` enquanto o `connect()` esperava |
| `websocket_unavailable` | o `connect()` não pôde abrir o WebSocket: este Node não tem um global (precisa do 22), ou o seu `WebSocketImpl` recusou |
| `voice_join_aborted` | `destroy()` enquanto um `voice.join()` chegava — a sala é deixada assim que a entrada chega |
| `voice_unavailable` | **das duas fontes**: o Gamerfy responde quando o servidor de mídia recusou a entrada (502) ou não respondeu (503), e o SDK cunha quando a resposta WHIP veio sem `Location` para desligar a sessão. Para o bot é a mesma notícia — a voz não está disponível agora |
| `invalid_voice_location` | o `Location` da resposta WHIP caiu fora da `apiUrl` configurada — confira a `apiUrl` |

Por isso o `status` é só pista: um 502 aqui pode ser resposta da API, um proxy no meio ou
o estado de um WebSocket, e quem ramifica no número trata os três igual. Uma recusa feita
antes de qualquer pedido (`invalid_api_url`, `invalid_gateway_url`, `invalid_rest_timeout_ms`,
`websocket_unavailable`) traz `status` 0 — e `timeout` também, pelo mesmo motivo: a chamada
foi abortada por este SDK, e não há resposta nenhuma para carregar um status de verdade. As
falhas da própria voz — o áudio e o WebRTC — não passam por aqui: são `VoiceSourceError`,
com a tabela no §8.

Um detalhe do que o SDK **não** embrulha: falha de rede na chamada HTTP (DNS fora,
conexão recusada) rejeita com o que o `fetch` levantou — um `TypeError`, não um
`GamerfyApiError`. E não há nova tentativa automática nas chamadas REST: só o gateway
reconecta sozinho.

## 10. Fechamentos do gateway e reconexão

O SDK reconecta esperando 1, 2, 4, 8, 16 e depois 30 s (com uma variação de 20 % para os
bots não voltarem todos no mesmo instante), e a espera volta para 1 s quando um `ready`
ou um `resumed` prova que a conexão serve. Cada fechamento passa pelo evento `disconnect`,
que diz se vem outra tentativa.

**Retomada.** Todo `dispatch` traz um `seq` e o `ready` traz um `session_id`; o SDK guarda os
dois e, depois de qualquer fechamento que não seja um dos quatro fatais, manda `resume` em vez
de `identify`. O servidor guarda a sessão por **2 minutos** e até **1.000 quadros**: dentro
disso você recebe o que passou durante a queda, na ordem, e depois um `resumed` — sem `ready`,
sem refazer `bot.guilds`, sem repetir nada que já chegou. Fora disso (mais tempo, mais quadros,
o servidor reiniciou, outro processo seu identificou com o mesmo token), o gateway responde
`4006` e o SDK identifica de novo: vem um `ready` novo e `bot.guilds` é refeito do zero — o
mesmo que acontecia sempre até a 0.1.x. O SDK pede a retomada acrescentando `?resume=1` ao
endereço do gateway; um gateway antigo ignora o parâmetro e tudo funciona como antes.

| Código | O que foi | Reconecta? |
|---|---|---|
| 1000 | o `destroy()` do seu programa | não |
| 1001 | o servidor está saindo do ar (um deploy) | sim |
| 1011 | falha do lado do servidor no meio de um quadro | sim |
| 4000 | um quadro que o protocolo não define: binário, JSON inválido, um segundo `identify`, ou um `resume` num gateway que não o conhece | sim |
| 4001 | nenhum `identify` em 10 s, ou um `heartbeat` antes dele | sim |
| **4002** | **token inválido, revogado ou vencido por inatividade** | **não** |
| **4003** | **o token foi trocado na aba Desenvolvedor** | **não** |
| **4004** | **outra conexão do mesmo bot assumiu** | **não** |
| **4005** | **o app foi apagado, ou o bot desligado** | **não** |
| 4006 | a sessão que o `resume` pediu não existe mais (mais de 2 min, mais de 1.000 quadros ou 1 MB, servidor reiniciado, o bot pediu um `seq` que a sessão não cobre — uma retomada que ficou para trás —, ou o nó atingiu o teto de 500 sessões estacionadas e a mais antiga caiu) | sim, com `identify` |
| 4008 | quadros demais (mais de 60 por minuto) | sim |
| 4009 | nenhum heartbeat por 75 s | sim |
| 4900 | o próprio SDK derrubou a conexão: nenhum `heartbeat_ack` desde a batida anterior | sim |

Os quatro em negrito são os únicos que param a reconexão, e cada um pede uma ação de
gente: trocar o token no programa (4002, 4003), descobrir que outra instância do seu bot
está no ar (4004), religar o bot (4005). O intervalo 4xxx **não** é a divisa — 4000, 4001,
4008 e 4009 são erros do próprio bot, e um bot que arrumou o quadro ou o ritmo deve
voltar. Um código que o SDK não conhece também é tentado de novo — inclusive o 1006 de uma
conexão que morreu sem quadro de fechamento nenhum, que é como a rede cortada no meio se
apresenta (e como o 4900 acima pode chegar, se o servidor não responder ao fechamento).
`CloseCode` e `NO_RECONNECT_CODES` estão exportados se você quiser comparar por nome, e o
`willReconnect` do evento `disconnect` é sempre a resposta definitiva — a tabela é a
leitura, ele é a decisão.

Depois de um fechamento sem volta, um `connect()` novo abre um socket de verdade — útil
quando o dono trocou o token e o seu programa releu o `.env`.

### O protocolo sem o cliente: `@gamerfy/bot/protocol`

O pacote publica um segundo ponto de entrada, `@gamerfy/bot/protocol`: o protocolo v1 e
nada mais — os esquemas zod de cada quadro e de cada evento (`serverFrameSchema`,
`dispatchSchemas`, `parseDispatch`), `CloseCode` e `isFatalClose`, e os três quadros que
um bot manda (`identifyFrame`, `resumeFrame`, `HEARTBEAT_FRAME`) e `resumableGatewayUrl`.
Ele não abre conexão nenhuma e não carrega o `werift`. Serve a quem escreve o próprio
cliente do gateway — outro runtime, um proxy,
uma ferramenta de teste — e quer ler o que chega com as mesmas regras do SDK. É também o
arquivo que o teste de contrato do backend confere contra o que o servidor manda de
verdade.

## 11. Limites de taxa

Três limites, os três com 429 `rate_limited` e `retryAfterMs` em milissegundos:

- **800 pedidos por minuto por app**, somando tudo o que o token chama;
- **5 mensagens a cada 5 segundos por canal**. É por canal, então um bot respondendo em
  dez salas nunca é freado pelo próprio trabalho nas outras. Uma recusa não gasta vaga:
  são cinco mensagens escritas, não cinco tentativas;
- **6 entradas de voz por minuto na mesma sala** (`bot.voice.join`). A recusa da porta
  (`channel_not_found`, `missing_permission`) não gasta vaga; mas toda entrada que passa
  da porta gasta, mesmo quando o servidor de mídia recusa ou não responde, porque o caro é
  a própria entrada — a conexão com o servidor de mídia e o entra-e-sai na sala de quem
  está lá. Tentar de novo em laço depois de uma falha esgota a vaga; espere o
  `retryAfterMs`. Uma entrada que o SDK refaz por TURN (§8, "Rede") são **dois** `POST`s e
  gasta duas vagas.

O `retryAfterMs` vem do corpo da resposta (`details.retry_after_ms`) e não do cabeçalho
`Retry-After`, que é em segundos e arredondaria uma espera de 1200 ms para 1 ou 2.

## 12. O token vence por inatividade

O token vale enquanto o bot usa: cada conexão ao gateway e cada chamada à API renova.
**90 dias sem nenhum uso** e ele deixa de valer — o gateway fecha com 4002 e as rotas
respondem 401 `bot_token_expired`. A aba Desenvolvedor mostra "Token expirado por
inatividade" e o botão de gerar outro. Um bot que fica de pé nunca encosta nesse prazo;
um bot de testes que dormiu três meses, sim.

## 13. Exemplos

Os dois exemplos rodam de dentro de `packages/bot-sdk`.

### `examples/dj.ts`

Alguém escreve "@dj tocar", o DJ responde no canal, entra na sala de quem pediu e toca. Um
`rate_limited` — a recusa que um bot ocupado mais encontra — não o derruba: ele espera o
`retryAfterMs` e tenta mais uma vez, e uma frase que não sai no canal vira uma linha de log.

```ts
/**
 * The DJ from the spec (§1, §9): somebody writes "@<bot> tocar", the DJ answers
 * in the channel, joins the room of whoever asked and plays.
 *
 *   GAMERFY_BOT_TOKEN=gfb_… DJ_AUDIO=./lofi.ogg npx tsx examples/dj.ts
 *
 * The bot needs Ver canais, Enviar mensagens, Conectar and Falar in that room.
 * `DJ_AUDIO` plays untouched when it is Opus in Ogg (`.ogg`/`.opus`); any other
 * format goes through the `ffmpeg` installed on THIS machine.
 *
 * Local stack: GAMERFY_API_URL=http://127.0.0.1:4502/api/public
 * GAMERFY_GATEWAY_URL=ws://127.0.0.1:4502/api/public/v1/gateway GAMERFY_ICE_LOOPBACK=1
 * GAMERFY_VOICE_TRANSPORT=relay (`auto` by default; `relay` enters through TURN
 * from the start — README §8)
 */
import { Bot, GamerfyApiError } from '../src/index.js';

const token = process.env.GAMERFY_BOT_TOKEN;
if (token === undefined) throw new Error('Defina GAMERFY_BOT_TOKEN com o token do bot.');
const audio = process.env.DJ_AUDIO ?? './lofi.ogg';

/** `auto` (default) or `relay`; anything else is refused here, before the bot exists, with the same words the constructor would use. */
const transport = process.env.GAMERFY_VOICE_TRANSPORT;
if (transport !== undefined && transport !== 'auto' && transport !== 'relay') throw new Error(`GAMERFY_VOICE_TRANSPORT precisa ser auto ou relay (veio ${transport}).`);

const bot = new Bot({
  token,
  // `gatewayUrl` is derived from `apiUrl` when it is left out, so pointing
  // `apiUrl` at a local backend is enough; both are read here because that is
  // what the end-to-end script hands over.
  apiUrl: process.env.GAMERFY_API_URL,
  gatewayUrl: process.env.GAMERFY_GATEWAY_URL,
  // Against the LiveKit of the compose: the container reaches this process only
  // through the loopback, so the candidate has to be in the offer.
  iceAdditionalHostAddresses: process.env.GAMERFY_ICE_LOOPBACK === '1' ? ['127.0.0.1'] : undefined,
  voice: { transport },
});

/**
 * One call, and one more after the wait the API named when it answered
 * `rate_limited` — the README's own shape ("Erros"). The limits are the
 * refusal a busy bot meets most (5 messages every 5 s in a channel, 6 voice
 * joins a minute in a room), and `retryAfterMs` says exactly how long to wait.
 */
async function afterRateLimit<T>(call: () => Promise<T>): Promise<T> {
  try {
    return await call();
  } catch (error) {
    if (!(error instanceof GamerfyApiError) || error.code !== 'rate_limited') throw error;
    await new Promise((resolve) => setTimeout(resolve, error.retryAfterMs ?? 1_000));
    return call();
  }
}

/**
 * A line in the channel that never takes the DJ down. The listener below is
 * `async`, and a rejection escaping it is fatal (Node 22): a send refused, or a
 * network blip, would otherwise end the program over a sentence — so the
 * failure is logged and the DJ goes on.
 */
async function say(channelId: string, content: string): Promise<void> {
  try {
    await afterRateLimit(() => bot.messages.send(channelId, content));
  } catch (error) {
    console.error('[dj] não consegui escrever no canal', error instanceof GamerfyApiError ? `${error.code}: ${error.message}` : error);
  }
}

bot.on('message', async (message) => {
  // `content` arrives `null` when the bot has no Ler mensagens in the channel
  // and was not mentioned (spec §7.4) — and being mentioned is this bot's cue,
  // so it reads the text of what it is asked to do with no such permission.
  if (!message.mentionsMe || !message.content?.includes('tocar')) return;
  const channelId = bot.voiceChannelOf(message.guildId, message.author.id);
  if (channelId === null) {
    await say(message.channelId, 'Entre numa sala de voz primeiro.');
    return;
  }
  await say(message.channelId, 'Tocando lofi');
  try {
    const voice = await afterRateLimit(() => bot.voice.join(channelId));
    // Which path got the bot in — the end-to-end proof reads this line, and so
    // does whoever runs a DJ inside a container with no UDP out.
    console.log(`[dj] na sala por ${voice.path}; servidores ICE do Link: ${voice.iceServerUrls.join(', ') || 'nenhum'}`);
    // `leave()` in a `finally`: a track that breaks in the middle (the bot
    // expelled from the room, an ffmpeg that died) must not leave the bot
    // sitting in the room with nobody able to hang it up.
    try {
      await voice.play(audio);
    } finally {
      // And the hang-up may not REPLACE the failure already on its way out: an
      // exception thrown from a `finally` beats the one in flight. `leave()`
      // swallows both halves of the hang-up itself (a refused `DELETE` and a
      // broken `peer.close()`), and this `catch` keeps anything else it may
      // grow from ever standing in for what really went wrong.
      await voice.leave().catch((leaveError: unknown) => console.error('[dj] falha ao sair da sala', leaveError));
    }
  } catch (error) {
    // The CODE and never the status: the SDK mints refusals of its own, so a
    // 502 can be the API, a proxy or the state of a socket (README, "Erros").
    if (error instanceof GamerfyApiError && error.code === 'missing_permission') {
      await say(message.channelId, 'Não tenho permissão de falar nessa sala.');
      return;
    }
    // Still refused after waiting once: the room had joins enough for the
    // minute. Said in the channel, and the DJ lives on for the next request.
    if (error instanceof GamerfyApiError && error.code === 'rate_limited') {
      await say(message.channelId, 'Entrei e saí dessa sala vezes demais agora; peça de novo daqui a pouco.');
      return;
    }
    // Everything else dies loudly, on purpose: a throw from a listener is the
    // bot's whole program (Node), and a DJ that swallows a failure here would
    // go on answering in the channel while the room hears silence.
    throw error;
  }
});

// Failures the SDK caught on its way to here (a frame off its shape, the
// gateway unreachable for a moment): the reconnection keeps running, and with
// no listener at all the SDK would print them itself.
bot.on('error', (error) => console.error('[dj]', error.message));
bot.on('ready', (user) => console.log(`[dj] conectado como ${user.displayName}`));

await bot.connect();
```

### `examples/moderator.ts`

Apaga a mensagem com palavra proibida e expulsa quem escreveu. A lista de palavras está
no lugar de qualquer coisa que julgue o texto — um modelo de IA, por exemplo.

```ts
/**
 * A moderator (spec §1 item 4): with Ler mensagens, Gerenciar mensagens and
 * Expulsar membros, it deletes a message with a forbidden word and kicks the
 * author. The word list is a stand-in for whatever judges the text — an AI
 * model, for one.
 *
 *   GAMERFY_BOT_TOKEN=gfb_… npx tsx examples/moderator.ts
 *   GAMERFY_BOT_TOKEN=gfb_… MODERATOR_WORDS=spam,golpe npx tsx examples/moderator.ts
 */
import { Bot, GamerfyApiError } from '../src/index.js';

const token = process.env.GAMERFY_BOT_TOKEN;
if (token === undefined) throw new Error('Defina GAMERFY_BOT_TOKEN com o token do bot.');
const FORBIDDEN = (process.env.MODERATOR_WORDS ?? 'palavrão').split(',').map((word) => word.trim().toLowerCase());

const bot = new Bot({ token, apiUrl: process.env.GAMERFY_API_URL, gatewayUrl: process.env.GAMERFY_GATEWAY_URL });

bot.on('message', async (message) => {
  // `content === null` is a message this bot may not read: no Ler mensagens in
  // that channel and no mention of itself (spec §7.4). There is nothing to
  // judge, and a moderator without that permission moderates nothing.
  if (message.author.bot || message.content === null) return;
  const text = message.content.toLowerCase();
  if (!FORBIDDEN.some((word) => text.includes(word))) return;
  try {
    await bot.messages.delete(message.channelId, message.id);
    await bot.members.kick(message.guildId, message.author.id);
    console.log(`[moderador] ${message.author.username} expulso de ${message.guildId}`);
  } catch (error) {
    // Caught whole, on purpose. A refusal of the API is a `GamerfyApiError`
    // (read `code`, never `status`), but a network blip rejects with whatever
    // `fetch` threw — the SDK does not wrap that one. Either way a throw from
    // inside a listener would take the program down (Node), and a moderator
    // that dies the first time it lacks a bit stops moderating the server.
    console.error('[moderador]', error instanceof GamerfyApiError ? `${error.code}: ${error.message}` : error);
  }
});

bot.on('error', (error) => console.error('[moderador]', error.message));
bot.on('ready', (user) => console.log(`[moderador] conectado como ${user.displayName}`));

await bot.connect();
```

## 14. O que esta fase não tem

Comandos com barra; eventos além dos da tabela do §4; intents; mais de uma conexão por
bot; anexo enviado por bot; bot em chat de live; listar membros de um servidor pelo SDK (a rota
`GET /v1/guilds/{id}/members` existe na API, o SDK ainda não a embrulha — dá para chamá-la
pelo `RestClient` exportado); uma sala que some do aviso de permissão com o bot dentro
(perda de *Ver canais*) não mexe na conexão de voz — se *Falar* foi junto, o servidor cortou
o microfone e o SDK não fica sabendo (§8, "Falar some no meio da chamada"); retomada
**entre nós** do backend (uma sessão vive no nó que a abriu).
